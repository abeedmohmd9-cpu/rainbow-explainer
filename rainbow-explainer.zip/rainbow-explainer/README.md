# Rainbow explainer (Remotion)

15 second, 1080x1920 explainer. Four scenes in `src/Explainer.tsx`:
title, sunlight, light bending in a raindrop, rainbow.

## Render on a computer
```
npm install
npm run studio   # live preview in the browser
npm run render   # writes out/explainer.mp4
```

## Render from an iPhone (free)
1. Create a free GitHub repo and upload these files (keep the folder layout,
   including `.github/workflows/render.yml`).
2. Open the repo in Safari, go to Actions > "Render video" > Run workflow.
3. When it finishes, open the run and download the `explainer-mp4` artifact
   (it is a zip; Files app unzips it, then Share > Save Video).

Alternative: open the repo in a GitHub Codespace from Safari, then run
`npm install && npm run render` in its terminal.

## Edit
- Text and colors: `src/Explainer.tsx`
- Length / size / fps: `src/Root.tsx`
