import {Config} from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setCodec("h264");
Config.setPixelFormat("yuv420p"); // needed so the MP4 plays on iPhone
Config.setOverwriteOutput(true);
