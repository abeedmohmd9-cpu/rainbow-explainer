import React from "react";
import {Composition} from "remotion";
import {Explainer} from "./Explainer";

export const FPS = 30;
export const DURATION = 450; // 15 seconds

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Explainer"
      component={Explainer}
      durationInFrames={DURATION}
      fps={FPS}
      width={1080} // vertical 9:16, good for iPhone / Reels / Shorts
      height={1920} // use 1920x1080 for a landscape video
    />
  );
};
