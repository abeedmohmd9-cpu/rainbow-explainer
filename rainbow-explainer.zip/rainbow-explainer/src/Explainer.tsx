import React from "react";
import {
  AbsoluteFill,
  Easing,
  Sequence,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

const BG = "#0b1026";
const COLORS = [
  "#ff3b30",
  "#ff9500",
  "#ffcc00",
  "#34c759",
  "#32ade6",
  "#5856d6",
  "#af52de",
];
const FONT = "Helvetica, Arial, sans-serif";

// ---- helpers ---------------------------------------------------------------

/** 0 -> 1 progress between two local frames, eased. */
const prog = (frame: number, from: number, to: number) =>
  interpolate(frame, [from, to], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: Easing.out(Easing.cubic),
  });

/** Fades a scene in and out over its own length. */
const SceneFade: React.FC<{length: number; children: React.ReactNode}> = ({
  length,
  children,
}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 12, length - 12, length], [0, 1, 1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return <AbsoluteFill style={{opacity}}>{children}</AbsoluteFill>;
};

const Caption: React.FC<{title: string; sub: string}> = ({title, sub}) => {
  const frame = useCurrentFrame();
  const p = prog(frame, 6, 26);
  return (
    <div
      style={{
        position: "absolute",
        left: 80,
        right: 80,
        bottom: 220,
        textAlign: "center",
        fontFamily: FONT,
        color: "white",
        opacity: p,
        transform: `translateY(${(1 - p) * 40}px)`,
      }}
    >
      <div style={{fontSize: 72, fontWeight: 800, marginBottom: 20}}>{title}</div>
      <div style={{fontSize: 44, color: "#b8c0e0", lineHeight: 1.3}}>{sub}</div>
    </div>
  );
};

// ---- scenes ----------------------------------------------------------------

const Title: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame, fps, config: {damping: 12}});
  const sub = prog(frame, 25, 50);
  return (
    <AbsoluteFill
      style={{justifyContent: "center", alignItems: "center", fontFamily: FONT}}
    >
      <div
        style={{
          color: "white",
          fontSize: 120,
          fontWeight: 900,
          textAlign: "center",
          lineHeight: 1.1,
          transform: `scale(${0.6 + 0.4 * s})`,
          opacity: s,
          padding: "0 80px",
        }}
      >
        How do
        <br />
        rainbows
        <br />
        form?
      </div>
      <div
        style={{
          marginTop: 60,
          display: "flex",
          gap: 14,
          opacity: sub,
        }}
      >
        {COLORS.map((c) => (
          <div
            key={c}
            style={{width: 60, height: 14, borderRadius: 7, background: c}}
          />
        ))}
      </div>
    </AbsoluteFill>
  );
};

/** Sun on the left, beam travelling to a raindrop in the middle. */
const SunlightScene: React.FC = () => {
  const frame = useCurrentFrame();
  const beam = prog(frame, 15, 70);
  const rays = Array.from({length: 12}, (_, i) => i);
  const sunX = 200;
  const sunY = 520;
  const dropX = 780;
  const dropY = 900;
  return (
    <AbsoluteFill>
      <svg width={1080} height={1920}>
        {rays.map((i) => {
          const a = (i / 12) * Math.PI * 2 + frame * 0.01;
          return (
            <line
              key={i}
              x1={sunX + Math.cos(a) * 120}
              y1={sunY + Math.sin(a) * 120}
              x2={sunX + Math.cos(a) * 165}
              y2={sunY + Math.sin(a) * 165}
              stroke="#ffd60a"
              strokeWidth={10}
              strokeLinecap="round"
            />
          );
        })}
        <circle cx={sunX} cy={sunY} r={95} fill="#ffd60a" />
        <line
          x1={sunX + 100}
          y1={sunY + 40}
          x2={sunX + 100 + (dropX - 80 - sunX - 100) * beam}
          y2={sunY + 40 + (dropY - sunY - 40) * beam}
          stroke="white"
          strokeWidth={14}
          strokeLinecap="round"
        />
        <path
          d={`M ${dropX} ${dropY - 90} C ${dropX + 70} ${dropY - 10}, ${
            dropX + 60
          } ${dropY + 70}, ${dropX} ${dropY + 70} C ${dropX - 60} ${dropY + 70}, ${
            dropX - 70
          } ${dropY - 10}, ${dropX} ${dropY - 90} Z`}
          fill="#32ade6"
          opacity={0.9}
        />
      </svg>
      <Caption
        title="Sunlight looks white"
        sub="But it is really a mix of every color."
      />
    </AbsoluteFill>
  );
};

/** Zoomed-in raindrop: the white beam splits into seven colors. */
const DropScene: React.FC = () => {
  const frame = useCurrentFrame();
  const cx = 620;
  const cy = 800;
  const r = 330;
  const inP = prog(frame, 8, 40);
  const entry = {x: cx - r * 0.95, y: cy - 60};
  return (
    <AbsoluteFill>
      <svg width={1080} height={1920}>
        <circle cx={cx} cy={cy} r={r} fill="#32ade6" opacity={0.25} />
        <circle
          cx={cx}
          cy={cy}
          r={r}
          fill="none"
          stroke="#7fd3ff"
          strokeWidth={8}
        />
        <line
          x1={40}
          y1={entry.y - 160}
          x2={40 + (entry.x - 40) * inP}
          y2={entry.y - 160 + 160 * inP}
          stroke="white"
          strokeWidth={14}
          strokeLinecap="round"
        />
        {COLORS.map((c, i) => {
          const p = prog(frame, 45 + i * 6, 95 + i * 6);
          const angle = (-16 + i * 5.2) * (Math.PI / 180) + 0.6;
          const len = 620;
          return (
            <line
              key={c}
              x1={entry.x}
              y1={entry.y}
              x2={entry.x + Math.cos(angle) * len * p}
              y2={entry.y + Math.sin(angle) * len * p}
              stroke={c}
              strokeWidth={12}
              strokeLinecap="round"
            />
          );
        })}
      </svg>
      <Caption
        title="Raindrops bend light"
        sub="Each color bends a different amount, so the colors spread apart."
      />
    </AbsoluteFill>
  );
};

/** Finale: the rainbow arcs draw in. */
const RainbowScene: React.FC = () => {
  const frame = useCurrentFrame();
  const cx = 540;
  const cy = 1000;
  return (
    <AbsoluteFill>
      <svg width={1080} height={1920}>
        {COLORS.map((c, i) => {
          const r = 460 - i * 48;
          const len = Math.PI * r;
          const p = prog(frame, i * 7, 50 + i * 7);
          return (
            <path
              key={c}
              d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
              fill="none"
              stroke={c}
              strokeWidth={44}
              strokeDasharray={len}
              strokeDashoffset={len * (1 - p)}
            />
          );
        })}
      </svg>
      <Caption
        title="That is a rainbow!"
        sub="Millions of drops, each sending one color to your eyes."
      />
    </AbsoluteFill>
  );
};

// ---- main composition ------------------------------------------------------

export const Explainer: React.FC = () => {
  return (
    <AbsoluteFill style={{background: BG}}>
      <Sequence from={0} durationInFrames={90}>
        <SceneFade length={90}>
          <Title />
        </SceneFade>
      </Sequence>
      <Sequence from={90} durationInFrames={120}>
        <SceneFade length={120}>
          <SunlightScene />
        </SceneFade>
      </Sequence>
      <Sequence from={210} durationInFrames={150}>
        <SceneFade length={150}>
          <DropScene />
        </SceneFade>
      </Sequence>
      <Sequence from={360} durationInFrames={90}>
        <SceneFade length={90}>
          <RainbowScene />
        </SceneFade>
      </Sequence>
    </AbsoluteFill>
  );
};
